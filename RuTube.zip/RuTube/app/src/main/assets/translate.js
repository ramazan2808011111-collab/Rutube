(async function () {
  // выключение
  if (window.__ruOn) {
    window.__ruOn = false;
    clearInterval(window.__ruTimer);
    Android.stop();
    var old = document.getElementById('__rusub');
    if (old) old.remove();
    var vv = document.querySelector('video');
    if (vv) vv.volume = window.__ruVol || 1;
    Android.state(false);
    return;
  }
  var v = document.querySelector('video');
  var id = new URL(location.href).searchParams.get('v');
  if (!v || !id) { Android.toast('Сначала откройте видео'); return; }

  try {
    Android.toast('Загружаю перевод...');
    var html = await (await fetch('/watch?v=' + id)).text();
    var m = html.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\});\s*(?:var|<\/script>)/);
    if (!m) throw new Error('нет данных видео');
    var pr = JSON.parse(m[1]);
    var tracks = pr.captions && pr.captions.playerCaptionsTracklistRenderer &&
      pr.captions.playerCaptionsTracklistRenderer.captionTracks;
    if (!tracks || !tracks.length) throw new Error('у видео нет субтитров');
    var tr = tracks.find(function (t) { return t.languageCode.indexOf('en') === 0; }) || tracks[0];
    var url = tr.baseUrl + '&fmt=json3' + (tr.languageCode === 'ru' ? '' : '&tlang=ru');
    var data = await (await fetch(url)).json();
    var cues = [];
    (data.events || []).forEach(function (e) {
      if (!e.segs) return;
      var t = e.segs.map(function (s) { return s.utf8; }).join('').replace(/\n/g, ' ').trim();
      if (t) cues.push({ s: e.tStartMs / 1000, e: (e.tStartMs + (e.dDurationMs || 2000)) / 1000, t: t });
    });
    if (!cues.length) throw new Error('перевод пустой');

    var box = document.createElement('div');
    box.id = '__rusub';
    box.style.cssText = 'position:fixed;left:5%;right:5%;bottom:90px;z-index:2147483647;' +
      'text-align:center;color:#fff;font:600 16px sans-serif;background:rgba(0,0,0,.65);' +
      'padding:6px 10px;border-radius:8px;pointer-events:none;display:none';
    document.body.appendChild(box);

    window.__ruVol = v.volume;
    v.volume = 0.15;           // приглушаем оригинал
    window.__ruOn = true;
    var last = null;
    window.__ruTimer = setInterval(function () {
      var vid = document.querySelector('video');
      if (!vid) return;
      var t = vid.currentTime;
      var cue = cues.find(function (c) { return t >= c.s && t <= c.e; });
      if (cue !== last) {
        last = cue;
        if (cue) { box.textContent = cue.t; box.style.display = 'block'; if (!vid.paused) Android.speak(cue.t); }
        else { box.style.display = 'none'; }
      }
    }, 200);
    Android.state(true);
  } catch (err) {
    Android.toast('Не удалось: ' + err.message);
  }
})();
